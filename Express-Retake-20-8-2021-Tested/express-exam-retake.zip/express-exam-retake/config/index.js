module.exports = {
    "PORT": 3000,
    "SALT_ROUNDS": 11,
    "JWT_LOGIN_SECRET": "THIS IS LOGIN SECRET",
    "LOGIN_COOKIE_NAME": "SESSION",
    "DB_LINK": "mongodb://localhost/exam-retake"
}